package mw.nwra.ewaterpermit.requestSchema;

import java.io.Serializable;

import mw.nwra.ewaterpermit.model.CoreCountry;
import mw.nwra.ewaterpermit.model.CoreCustomerType;
import mw.nwra.ewaterpermit.model.CoreDistrict;
import mw.nwra.ewaterpermit.model.SysSalutation;

public class SysUserAccountCreateRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	private String username;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String password;

	private String companyRegisteredName;
	private String companyRegistrationNumber;
	private String companyTradingName;
	private CoreCustomerType coreCustomerType;
	private String designation;
	private CoreDistrict coreDistrict;
	private String mobileNumber;
	private String nationalId;
	private String physicalAddress;
	private String postalAddress;
	private SysSalutation sysSalutation;
	private String phoneNumber;
	private String passportNumber;
	private CoreCountry passportCountry;

	public SysUserAccountCreateRequest() {
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyRegisteredName() {
		return companyRegisteredName;
	}

	public void setCompanyRegisteredName(String companyRegisteredName) {
		this.companyRegisteredName = companyRegisteredName;
	}

	public String getCompanyRegistrationNumber() {
		return companyRegistrationNumber;
	}

	public void setCompanyRegistrationNumber(String companyRegistrationNumber) {
		this.companyRegistrationNumber = companyRegistrationNumber;
	}

	public String getCompanyTradingName() {
		return companyTradingName;
	}

	public void setCompanyTradingName(String companyTradingName) {
		this.companyTradingName = companyTradingName;
	}

	public CoreCustomerType getCoreCustomerType() {
		return coreCustomerType;
	}

	public void setCoreCustomerType(CoreCustomerType coreCustomerType) {
		this.coreCustomerType = coreCustomerType;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public CoreDistrict getCoreDistrict() {
		return coreDistrict;
	}

	public void setCoreDistrict(CoreDistrict coreDistrict) {
		this.coreDistrict = coreDistrict;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getPhysicalAddress() {
		return physicalAddress;
	}

	public void setPhysicalAddress(String physicalAddress) {
		this.physicalAddress = physicalAddress;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public SysSalutation getSysSalutation() {
		return sysSalutation;
	}

	public void setSysSalutation(SysSalutation sysSalutation) {
		this.sysSalutation = sysSalutation;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public CoreCountry getPassportCountry() {
		return passportCountry;
	}

	public void setPassportCountry(CoreCountry passportCountry) {
		this.passportCountry = passportCountry;
	}

}