package mw.nwra.ewaterpermit.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_customer_type")
@NamedQuery(name = "CoreCustomerType.findAll", query = "SELECT c FROM CoreCustomerType c")
public class CoreCustomerType extends BaseEntity {

	private String description;

	private String name;

	// bi-directional many-to-one association to CoreCustomer
	@JsonIgnore
	@OneToMany(mappedBy = "coreCustomerType")
	private List<SysUserAccount> sysUserAccounts;

	public CoreCustomerType() {
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SysUserAccount> getSysUserAccounts() {
		return this.sysUserAccounts;
	}

	public void setSysUserAccounts(List<SysUserAccount> sysUserAccounts) {
		this.sysUserAccounts = sysUserAccounts;
	}

	public SysUserAccount addSysUserAccount(SysUserAccount sysUserAccount) {
		getSysUserAccounts().add(sysUserAccount);
		sysUserAccount.setCoreCustomerType(this);

		return sysUserAccount;
	}

	public SysUserAccount removeSysUserAccount(SysUserAccount sysUserAccount) {
		getSysUserAccounts().remove(sysUserAccount);
		sysUserAccount.setCoreCustomerType(null);

		return sysUserAccount;
	}

}