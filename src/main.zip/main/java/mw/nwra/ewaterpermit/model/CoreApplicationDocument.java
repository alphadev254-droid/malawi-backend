package mw.nwra.ewaterpermit.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_application_document")
@NamedQuery(name = "CoreApplicationDocument.findAll", query = "SELECT c FROM CoreApplicationDocument c")
public class CoreApplicationDocument extends BaseEntity {
	@Column(name = "document_url")
	private String documentUrl;

	// bi-directional many-to-one association to CoreLicenseApplication
	@ManyToOne
	@JoinColumn(name = "license_application_id")
	private CoreLicenseApplication coreLicenseApplication;

	// bi-directional many-to-one association to CoreDocumentCategory
	@ManyToOne
	@JoinColumn(name = "license_requirement_id")
	private CoreLicenseRequirement coreLicenseRequirement;

	public CoreApplicationDocument() {
	}

	public String getDocumentUrl() {
		return this.documentUrl;
	}

	public void setDocumentUrl(String documentUrl) {
		this.documentUrl = documentUrl;
	}

	public CoreLicenseApplication getCoreLicenseApplication() {
		return this.coreLicenseApplication;
	}

	public void setCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication) {
		this.coreLicenseApplication = coreLicenseApplication;
	}

	public CoreLicenseRequirement getCoreLicenseRequirement() {
		return coreLicenseRequirement;
	}

	public void setCoreLicenseRequirement(CoreLicenseRequirement coreLicenseRequirement) {
		this.coreLicenseRequirement = coreLicenseRequirement;
	}

}