package mw.nwra.ewaterpermit.model;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_license_application")
@NamedQuery(name = "CoreLicenseApplication.findAll", query = "SELECT c FROM CoreLicenseApplication c")
public class CoreLicenseApplication extends BaseEntity {

	@Column(name = "date_submitted")
	private Timestamp dateSubmitted;

	@Column(name = "dest_easting")
	private String destEasting;

	@Column(name = "dest_hectarage")
	private String destHectarage;

	@Column(name = "dest_northing")
	private String destNorthing;

	@Column(name = "dest_owner_fullname")
	private String destOwnerFullname;

	@Column(name = "dest_plot_number")
	private String destPlotNumber;

	@Column(name = "dest_ta")
	private String destTa;

	@Column(name = "dest_village")
	private String destVillage;

	@Column(name = "source_easting")
	private String sourceEasting;

	@Column(name = "source_hectarage")
	private String sourceHectarage;

	@Column(name = "source_northing")
	private String sourceNorthing;

	@Column(name = "source_owner_fullname")
	private String sourceOwnerFullname;

	@Column(name = "source_plot_number")
	private String sourcePlotNumber;

	@Column(name = "source_ta")
	private String sourceTa;

	@Column(name = "source_village")
	private String sourceVillage;

	// bi-directional many-to-one association to CoreLandRegime
	@ManyToOne
	@JoinColumn(name = "water_source_id")
	private CoreWaterSource coreWaterSource;

	// bi-directional many-to-one association to CoreLandRegime
	@ManyToOne
	@JoinColumn(name = "dest_land_regime_id")
	private CoreLandRegime destLandRegime;

	// bi-directional many-to-one association to CoreLandRegime
	@ManyToOne
	@JoinColumn(name = "source_land_regime_id")
	private CoreLandRegime sourceLandRegime;

	// bi-directional many-to-one association to CoreLicenseType
	@ManyToOne
	@JoinColumn(name = "license_type_id")
	private CoreLicenseType coreLicenseType;

	// bi-directional many-to-one association to CoreLicense
	@ManyToOne
	@JoinColumn(name = "current_licence_id")
	private CoreLicense currentLicense;

	// bi-directional many-to-one association to CoreLicense
	@ManyToOne
	@JoinColumn(name = "application_status_id")
	private CoreApplicationStatus coreApplicationStatus;

	// bi-directional many-to-one association to CoreLicense
	@ManyToOne
	@JoinColumn(name = "application_step_id")
	private CoreApplicationStep coreApplicationStep;

	// bi-directional many-to-one association to CoreLicense
	@ManyToOne
	@JoinColumn(name = "user_account_id")
	private SysUserAccount sysUserAccount;

	// bi-directional many-to-one association to CoreApplicationDocument
	@JsonIgnore
	@OneToMany(mappedBy = "coreLicenseApplication")
	private List<CoreApplicationDocument> coreApplicationDocuments;

	// bi-directional many-to-one association to CoreApplicationPayment
	@JsonIgnore
	@OneToMany(mappedBy = "coreLicenseApplication")
	private List<CoreApplicationPayment> coreApplicationPayments;

	// bi-directional many-to-one association to CoreLicense
	@JsonIgnore
	@OneToMany(mappedBy = "coreLicenseApplication")
	private List<CoreLicense> coreLicenses;

	// bi-directional many-to-one association to CoreLicenseWaterUse
	@JsonIgnore
	@OneToMany(mappedBy = "coreLicenseApplication")
	private List<CoreLicenseWaterUse> coreLicenseWaterUses;

	@Column(name = "existing_borehole_count")
	private Integer existingBoreholeCount;

	@Column(name = "permit_duration")
	private Double permitDuration;

	@Column(name = "nearby_water_utility_board")
	private String nearbyWaterUtilityBoard;

	@Column(name = "alt_water_source")
	private String altWaterSource;

	@Column(name = "alt_other_water")
	private String altOtherWater;

	public CoreLicenseApplication() {
	}

	public Timestamp getDateSubmitted() {
		return dateSubmitted;
	}

	public void setDateSubmitted(Timestamp dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}

	public String getDestEasting() {
		return this.destEasting;
	}

	public void setDestEasting(String destEasting) {
		this.destEasting = destEasting;
	}

	public String getDestHectarage() {
		return this.destHectarage;
	}

	public void setDestHectarage(String destHectarage) {
		this.destHectarage = destHectarage;
	}

	public String getDestNorthing() {
		return this.destNorthing;
	}

	public void setDestNorthing(String destNorthing) {
		this.destNorthing = destNorthing;
	}

	public String getDestOwnerFullname() {
		return this.destOwnerFullname;
	}

	public void setDestOwnerFullname(String destOwnerFullname) {
		this.destOwnerFullname = destOwnerFullname;
	}

	public String getDestPlotNumber() {
		return this.destPlotNumber;
	}

	public void setDestPlotNumber(String destPlotNumber) {
		this.destPlotNumber = destPlotNumber;
	}

	public String getDestTa() {
		return this.destTa;
	}

	public void setDestTa(String destTa) {
		this.destTa = destTa;
	}

	public String getDestVillage() {
		return this.destVillage;
	}

	public void setDestVillage(String destVillage) {
		this.destVillage = destVillage;
	}

	public String getSourceEasting() {
		return this.sourceEasting;
	}

	public void setSourceEasting(String sourceEasting) {
		this.sourceEasting = sourceEasting;
	}

	public String getSourceHectarage() {
		return this.sourceHectarage;
	}

	public void setSourceHectarage(String sourceHectarage) {
		this.sourceHectarage = sourceHectarage;
	}

	public String getSourceNorthing() {
		return this.sourceNorthing;
	}

	public void setSourceNorthing(String sourceNorthing) {
		this.sourceNorthing = sourceNorthing;
	}

	public String getSourceOwnerFullname() {
		return this.sourceOwnerFullname;
	}

	public void setSourceOwnerFullname(String sourceOwnerFullname) {
		this.sourceOwnerFullname = sourceOwnerFullname;
	}

	public String getSourcePlotNumber() {
		return this.sourcePlotNumber;
	}

	public void setSourcePlotNumber(String sourcePlotNumber) {
		this.sourcePlotNumber = sourcePlotNumber;
	}

	public String getSourceTa() {
		return this.sourceTa;
	}

	public void setSourceTa(String sourceTa) {
		this.sourceTa = sourceTa;
	}

	public String getSourceVillage() {
		return this.sourceVillage;
	}

	public void setSourceVillage(String sourceVillage) {
		this.sourceVillage = sourceVillage;
	}

	public CoreLandRegime getSourceLandRegime() {
		return this.sourceLandRegime;
	}

	public void setSourceLandRegime(CoreLandRegime sourceLandRegime) {
		this.sourceLandRegime = sourceLandRegime;
	}

	public CoreLandRegime getDestLandRegime() {
		return this.destLandRegime;
	}

	public void setDestLandRegime(CoreLandRegime destLandRegime) {
		this.destLandRegime = destLandRegime;
	}

	public List<CoreApplicationDocument> getCoreApplicationDocuments() {
		return this.coreApplicationDocuments;
	}

	public void setCoreApplicationDocuments(List<CoreApplicationDocument> coreApplicationDocuments) {
		this.coreApplicationDocuments = coreApplicationDocuments;
	}

	public CoreApplicationDocument addCoreApplicationDocument(CoreApplicationDocument coreApplicationDocument) {
		getCoreApplicationDocuments().add(coreApplicationDocument);
		coreApplicationDocument.setCoreLicenseApplication(this);

		return coreApplicationDocument;
	}

	public CoreApplicationDocument removeCoreApplicationDocument(CoreApplicationDocument coreApplicationDocument) {
		getCoreApplicationDocuments().remove(coreApplicationDocument);
		coreApplicationDocument.setCoreLicenseApplication(null);

		return coreApplicationDocument;
	}

	public List<CoreApplicationPayment> getCoreApplicationPayments() {
		return this.coreApplicationPayments;
	}

	public void setCoreApplicationPayments(List<CoreApplicationPayment> coreApplicationPayments) {
		this.coreApplicationPayments = coreApplicationPayments;
	}

	public CoreApplicationPayment addCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment) {
		getCoreApplicationPayments().add(coreApplicationPayment);
		coreApplicationPayment.setCoreLicenseApplication(this);

		return coreApplicationPayment;
	}

	public CoreApplicationPayment removeCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment) {
		getCoreApplicationPayments().remove(coreApplicationPayment);
		coreApplicationPayment.setCoreLicenseApplication(null);

		return coreApplicationPayment;
	}

	public List<CoreLicense> getCoreLicenses() {
		return this.coreLicenses;
	}

	public void setCoreLicenses(List<CoreLicense> coreLicenses) {
		this.coreLicenses = coreLicenses;
	}

	public CoreLicense addCoreLicens(CoreLicense coreLicens) {
		getCoreLicenses().add(coreLicens);
		coreLicens.setCoreLicenseApplication(this);

		return coreLicens;
	}

	public CoreLicense removeCoreLicens(CoreLicense coreLicens) {
		getCoreLicenses().remove(coreLicens);
		coreLicens.setCoreLicenseApplication(null);

		return coreLicens;
	}

	public CoreLicenseType getCoreLicenseType() {
		return this.coreLicenseType;
	}

	public void setCoreLicenseType(CoreLicenseType coreLicenseType) {
		this.coreLicenseType = coreLicenseType;
	}

	public CoreLicense getCurrentLicense() {
		return currentLicense;
	}

	public void setCurrentLicense(CoreLicense currentLicense) {
		this.currentLicense = currentLicense;
	}

	public List<CoreLicenseWaterUse> getCoreLicenseWaterUses() {
		return this.coreLicenseWaterUses;
	}

	public void setCoreLicenseWaterUses(List<CoreLicenseWaterUse> coreLicenseWaterUses) {
		this.coreLicenseWaterUses = coreLicenseWaterUses;
	}

	public CoreLicenseWaterUse addCoreLicenseWaterUs(CoreLicenseWaterUse coreLicenseWaterUs) {
		getCoreLicenseWaterUses().add(coreLicenseWaterUs);
		coreLicenseWaterUs.setCoreLicenseApplication(this);

		return coreLicenseWaterUs;
	}

	public CoreLicenseWaterUse removeCoreLicenseWaterUs(CoreLicenseWaterUse coreLicenseWaterUs) {
		getCoreLicenseWaterUses().remove(coreLicenseWaterUs);
		coreLicenseWaterUs.setCoreLicenseApplication(null);

		return coreLicenseWaterUs;
	}

	public CoreWaterSource getCoreWaterSource() {
		return coreWaterSource;
	}

	public void setCoreWaterSource(CoreWaterSource coreWaterSource) {
		this.coreWaterSource = coreWaterSource;
	}

	public CoreApplicationStatus getCoreApplicationStatus() {
		return coreApplicationStatus;
	}

	public void setCoreApplicationStatus(CoreApplicationStatus coreApplicationStatus) {
		this.coreApplicationStatus = coreApplicationStatus;
	}

	public CoreApplicationStep getCoreApplicationStep() {
		return coreApplicationStep;
	}

	public void setCoreApplicationStep(CoreApplicationStep coreApplicationStep) {
		this.coreApplicationStep = coreApplicationStep;
	}

	public SysUserAccount getSysUserAccount() {
		return sysUserAccount;
	}

	public void setSysUserAccount(SysUserAccount sysUserAccount) {
		this.sysUserAccount = sysUserAccount;
	}

	public Integer getExistingBoreholeCount() {
		return existingBoreholeCount;
	}

	public void setExistingBoreholeCount(Integer existingBoreholeCount) {
		this.existingBoreholeCount = existingBoreholeCount;
	}

	public Double getPermitDuration() {
		return permitDuration;
	}

	public void setPermitDuration(Double permitDuration) {
		this.permitDuration = permitDuration;
	}

	public String getNearbyWaterUtilityBoard() {
		return nearbyWaterUtilityBoard;
	}

	public void setNearbyWaterUtilityBoard(String nearbyWaterUtilityBoard) {
		this.nearbyWaterUtilityBoard = nearbyWaterUtilityBoard;
	}

	public String getAltWaterSource() {
		return altWaterSource;
	}

	public void setAltWaterSource(String altWaterSource) {
		this.altWaterSource = altWaterSource;
	}

	public String getAltOtherWater() {
		return altOtherWater;
	}

	public void setAltOtherWater(String altOtherWater) {
		this.altOtherWater = altOtherWater;
	}

}