package mw.nwra.ewaterpermit.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_water_resource_unit")
@NamedQuery(name = "CoreWaterResourceUnit.findAll", query = "SELECT c FROM CoreWaterResourceUnit c")
public class CoreWaterResourceUnit extends BaseEntity {

	@Lob
	@Column(name = "geo_geometry")
	private byte[] geoGeometry;

	@Lob
	@Column(name = "geo_property")
	private byte[] geoProperty;

	@Lob
	@Column(name = "geo_type")
	private String geoType;

	// bi-directional many-to-one association to CoreWaterResourceArea
	@ManyToOne
	@JoinColumn(name = "water_resource_area_id")
	private CoreWaterResourceArea coreWaterResourceArea;

	public CoreWaterResourceUnit() {
	}

	public byte[] getGeoGeometry() {
		return this.geoGeometry;
	}

	public void setGeoGeometry(byte[] geoGeometry) {
		this.geoGeometry = geoGeometry;
	}

	public byte[] getGeoProperty() {
		return this.geoProperty;
	}

	public void setGeoProperty(byte[] geoProperty) {
		this.geoProperty = geoProperty;
	}

	public String getGeoType() {
		return this.geoType;
	}

	public void setGeoType(String geoType) {
		this.geoType = geoType;
	}

	public CoreWaterResourceArea getCoreWaterResourceArea() {
		return this.coreWaterResourceArea;
	}

	public void setCoreWaterResourceArea(CoreWaterResourceArea coreWaterResourceArea) {
		this.coreWaterResourceArea = coreWaterResourceArea;
	}
}