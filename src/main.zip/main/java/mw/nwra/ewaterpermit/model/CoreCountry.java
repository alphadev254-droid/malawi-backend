package mw.nwra.ewaterpermit.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_country")
@NamedQuery(name = "CoreCountry.findAll", query = "SELECT c FROM CoreCountry c")
public class CoreCountry extends BaseEntity {
	private String iso;

	private String iso3;

	private String name;

	private String nicename;

	private String numcode;

	private String phonecode;

	// bi-directional many-to-one association to SysUserAccount
	@JsonIgnore
	@OneToMany(mappedBy = "coreCountry")
	private List<SysUserAccount> sysUserAccounts;

	public CoreCountry() {
		super();
	}

	public String getIso() {
		return iso;
	}

	public void setIso(String iso) {
		this.iso = iso;
	}

	public String getIso3() {
		return iso3;
	}

	public void setIso3(String iso3) {
		this.iso3 = iso3;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNicename() {
		return nicename;
	}

	public void setNicename(String nicename) {
		this.nicename = nicename;
	}

	public String getNumcode() {
		return numcode;
	}

	public void setNumcode(String numcode) {
		this.numcode = numcode;
	}

	public String getPhonecode() {
		return phonecode;
	}

	public void setPhonecode(String phonecode) {
		this.phonecode = phonecode;
	}

	public List<SysUserAccount> getSysUserAccounts() {
		return this.sysUserAccounts;
	}

	public void setSysUserAccounts(List<SysUserAccount> sysUserAccounts) {
		this.sysUserAccounts = sysUserAccounts;
	}

	public SysUserAccount addSysUserAccount(SysUserAccount sysUserAccount) {
		getSysUserAccounts().add(sysUserAccount);
		sysUserAccount.setCoreCountry(this);

		return sysUserAccount;
	}

	public SysUserAccount removeSysUserAccount(SysUserAccount sysUserAccount) {
		getSysUserAccounts().remove(sysUserAccount);
		sysUserAccount.setCoreCountry(null);

		return sysUserAccount;
	}
}
