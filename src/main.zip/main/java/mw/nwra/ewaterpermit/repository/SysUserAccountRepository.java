package mw.nwra.ewaterpermit.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mw.nwra.ewaterpermit.model.SysUserAccount;

@Repository
public interface SysUserAccountRepository extends JpaRepository<SysUserAccount, String> {
	SysUserAccount findByUsername(String username);

	SysUserAccount findByEmailAddress(String emailAddress);

	SysUserAccount findByPhoneNumber(String phoneNumber);

	@Query("SELECT d FROM SysUserAccount d WHERE " + " d.firstName LIKE %:search% OR "
			+ " d.lastName LIKE %:search% OR " + " d.emailAddress LIKE %:search% OR "
			+ " d.sysUserGroup.name LIKE %:search%")
	Page<SysUserAccount> findAll(@Param("search") String search, Pageable pageable);
}
