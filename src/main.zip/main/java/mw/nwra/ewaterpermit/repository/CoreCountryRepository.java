package mw.nwra.ewaterpermit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mw.nwra.ewaterpermit.model.CoreCountry;

@Repository
public interface CoreCountryRepository extends JpaRepository<CoreCountry, String> {
	CoreCountry findByIso(String iso);

	CoreCountry findByIso3(String iso3);

}
