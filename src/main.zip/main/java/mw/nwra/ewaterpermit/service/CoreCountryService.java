package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.CoreCountry;

public interface CoreCountryService {
	public List<CoreCountry> getAllCountries();

	public List<CoreCountry> getAllCountries(int page, int limit);

	CoreCountry getCoreCountryById(String countryId);

	CoreCountry getCoreCountryByIso(String iso);

	CoreCountry getCoreCountryByIso3(String iso3);

	void deleteCoreCountry(String countryId);

	CoreCountry addCoreCountry(CoreCountry country);

	CoreCountry editCoreCountry(CoreCountry country);

}