package mw.nwra.ewaterpermit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import mw.nwra.ewaterpermit.model.CoreCountry;
import mw.nwra.ewaterpermit.repository.CoreCountryRepository;
import mw.nwra.ewaterpermit.util.AppUtil;

@Service(value = "coreCountryService")
public class CoreCountryServiceImpl implements CoreCountryService {

	@Autowired
	private CoreCountryRepository countryRepository;

	@Override
	public List<CoreCountry> getAllCountries() {

		return this.countryRepository.findAll();
	}

	@Override
	public List<CoreCountry> getAllCountries(int page, int limit) {
		Page<CoreCountry> countries = this.countryRepository
				.findAll(AppUtil.getPageRequest(page, limit, "dateCreated", "desc"));
		return countries.getContent();
	}

	@Override
	public CoreCountry getCoreCountryById(String countryId) {

		return this.countryRepository.findById(countryId).orElse(null);
	}

	@Override
	public void deleteCoreCountry(String countryId) {
		this.countryRepository.deleteById(countryId);
	}

	@Override
	public CoreCountry addCoreCountry(CoreCountry country) {
		return this.countryRepository.saveAndFlush(country);
	}

	@Override
	public CoreCountry editCoreCountry(CoreCountry country) {
		return this.countryRepository.saveAndFlush(country);
	}

	@Override
	public CoreCountry getCoreCountryByIso(String iso) {
		return this.countryRepository.findByIso(iso);
	}

	@Override
	public CoreCountry getCoreCountryByIso3(String iso3) {
		return this.countryRepository.findByIso3(iso3);
	}

}
