package mw.nwra.ewaterpermit.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.constant.Action;
import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.responseSchema.SearchResponse;
import mw.nwra.ewaterpermit.service.SysUserAccountService;
import mw.nwra.ewaterpermit.util.AppUtil;
import mw.nwra.ewaterpermit.util.PasswordHash;

@RestController
@RequestMapping(value = "/v1/sys-user-accounts")
public class SysUserAccountController {
	private final String OBJ = "user-accounts";
	@Autowired
	private SysUserAccountService userAccountService;

	@GetMapping
	public SearchResponse getAllSysUserAccounts(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "20") int limit,
			@RequestParam(value = "query", defaultValue = "") String query) {
		SearchResponse userAccounts = this.userAccountService.getAllSysUserAccounts(page, limit, query);
		if (userAccounts == null) {
			throw new EntityNotFoundException("User accounts not found");
		}
		@SuppressWarnings("unchecked")
		List<SysUserAccount> accounts = this.sanitizeSysUserAccounts((List<SysUserAccount>) userAccounts.getData());
		userAccounts.setData(accounts);
		return userAccounts;
	}

	@GetMapping(path = "/{id}")
	public SysUserAccount getSysUserAccountById(@PathVariable(name = "id") String id) {
		SysUserAccount userAccount = this.userAccountService.getSysUserAccountById(id);
		if (userAccount == null) {
			throw new EntityNotFoundException("User account with id '" + id + "' not found");
		}
		return AppUtil.sanitizeSysUserAccount(userAccount);
	}

	@PostMapping
	public SysUserAccount createSysUserAccount(@RequestBody Map<String, Object> userAccountRequest,
			@RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.CREATE.toString());

		SysUserAccount userAccount = (SysUserAccount) AppUtil.objectToClass(SysUserAccount.class, userAccountRequest);
		if (userAccount == null) {
			throw new ForbiddenException("Could not create the user account");
		}
		if (userAccount.getPassword() != null && !userAccount.getPassword().trim().isEmpty()) {
			// hash password supplied
			userAccount.setPassword(PasswordHash.hashPassword(userAccount.getPassword()));
		} else {
			throw new ForbiddenException("Could not create the user account. Password unavailable.");
		}
		userAccount.setDateCreated(new Timestamp(new Date().getTime()));
		this.userAccountService.createSysUserAccount(userAccount);
		return AppUtil.sanitizeSysUserAccount(userAccount);
	}

	@PutMapping(path = "/{id}")
	public SysUserAccount updateSysUserAccount(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> userAccountRequest, @RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.UPDATE.toString());

		SysUserAccount userAccount = this.userAccountService.getSysUserAccountById(id);
		if (userAccount == null) {
			throw new EntityNotFoundException("User account not found");
		}

		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(SysUserAccount.class, userAccountRequest);

		SysUserAccount userAccountFromObj = (SysUserAccount) AppUtil.objectToClass(SysUserAccount.class,
				userAccountRequest);
		if (userAccountFromObj == null) {
			throw new ForbiddenException("Could not update the user account");
		}
		SysUserAccount loggedUser = AppUtil.getLoggedInUser(token);
		if (loggedUser != null && loggedUser.getSysUserGroup() != null
				&& loggedUser.getSysUserGroup().getName().equalsIgnoreCase("admin")) {

		} else if (!loggedUser.getId().equals(userAccountFromObj.getId())) {
			throw new EntityNotFoundException("Action denied. Not your acccount");
		}
		if (userAccountFromObj.getPassword() != null && !userAccountFromObj.getPassword().trim().isEmpty()) {
			// if new password supplied
			userAccountFromObj.setPassword(PasswordHash.hashPassword(userAccountFromObj.getPassword()));
		} else {
			userAccountFromObj.setPassword(userAccount.getPassword());
		}
		if (userAccountFromObj.getEmailAddress() == null) {
			userAccountFromObj.setEmailAddress(userAccount.getEmailAddress());
		}
		BeanUtils.copyProperties(userAccountFromObj, userAccount, propertiesToIgnore);
		userAccount.setDateUpdated(new Timestamp(new Date().getTime()));
		this.userAccountService.updateSysUserAccount(userAccount);
		return AppUtil.sanitizeSysUserAccount(userAccount);
	}

	@DeleteMapping(path = "/{id}")
	public void deleteSysUserAccount(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.DELETE.toString());

		SysUserAccount userAccount = this.userAccountService.getSysUserAccountById(id);
		if (userAccount == null) {
			throw new EntityNotFoundException("User account with id '" + id + "' not found");
		}
		this.userAccountService.deleteSysUserAccount(userAccount.getId());
	}

	private List<SysUserAccount> sanitizeSysUserAccounts(List<SysUserAccount> userAccounts) {
		return userAccounts.stream().map(userAccount -> {
			return AppUtil.sanitizeSysUserAccount(userAccount);
		}).collect(Collectors.toList());
	}
}
