package mw.nwra.ewaterpermit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreCountry;
import mw.nwra.ewaterpermit.service.CoreCountryService;

@RestController
@RequestMapping(value = "/v1/countries")
public class CoreCountryController {

	@Autowired
	private CoreCountryService coreCountryService;

	@GetMapping(path = "")
	public List<CoreCountry> getAllCountries(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<CoreCountry> countries = this.coreCountryService.getAllCountries(page, limit);
		if (countries.isEmpty()) {
			throw new EntityNotFoundException("Countries not found");
		}
		return countries;
	}

	@GetMapping(path = "/{id}")
	public CoreCountry getCoreCountryById(@PathVariable(name = "id") String coreCountryId) {
		CoreCountry coreCountry = this.coreCountryService.getCoreCountryById(coreCountryId);
		if (coreCountry == null) {
			throw new EntityNotFoundException("CoreCountry not found");
		}
		return coreCountry;
	}

	@GetMapping(path = "/{iso}/iso")
	public CoreCountry getCoreCountryByIso(@PathVariable(name = "iso") String iso) {
		CoreCountry coreCountry = this.coreCountryService.getCoreCountryByIso(iso);
		if (coreCountry == null) {
			throw new EntityNotFoundException("CoreCountry not found");
		}
		return coreCountry;
	}

	@GetMapping(path = "/{iso3}/iso3")
	public CoreCountry getCoreCountryByIso3(@PathVariable(name = "iso3") String iso3) {
		CoreCountry coreCountry = this.coreCountryService.getCoreCountryByIso3(iso3);
		if (coreCountry == null) {
			throw new EntityNotFoundException("CoreCountry not found");
		}
		return coreCountry;
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCoreCountry(@PathVariable(name = "id") String coreCountryId) {
		throw new ForbiddenException("Operation denied!");
	}
}
