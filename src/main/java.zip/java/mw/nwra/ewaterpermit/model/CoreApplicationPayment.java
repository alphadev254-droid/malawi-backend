package mw.nwra.ewaterpermit.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "core_application_payment")
@NamedQuery(name = "CoreApplicationPayment.findAll", query = "SELECT c FROM CoreApplicationPayment c")
public class CoreApplicationPayment extends BaseEntity {

	@Column(name = "amount_paid")
	private double amountPaid;

	// bi-directional many-to-one association to CoreLicenseApplication
	@ManyToOne
	@JoinColumn(name = "license_application_id")
	private CoreLicenseApplication coreLicenseApplication;

	// bi-directional many-to-one association to CoreFeesType
	@ManyToOne
	@JoinColumn(name = "fees_type_id")
	private CoreFeesType coreFeesType;

	public CoreApplicationPayment() {
	}

	public double getAmountPaid() {
		return this.amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public CoreLicenseApplication getCoreLicenseApplication() {
		return this.coreLicenseApplication;
	}

	public void setCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication) {
		this.coreLicenseApplication = coreLicenseApplication;
	}

	public CoreFeesType getCoreFeesType() {
		return this.coreFeesType;
	}

	public void setCoreFeesType(CoreFeesType coreFeesType) {
		this.coreFeesType = coreFeesType;
	}

}