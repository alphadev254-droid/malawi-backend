package mw.nwra.ewaterpermit.requestSchema;

import java.io.Serializable;

public class SysUserAccountCreateRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	private String username;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String password;

	public SysUserAccountCreateRequest() {
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}