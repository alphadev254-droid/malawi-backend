package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.CoreLicense;

public interface CoreLicenseService {
	public List<CoreLicense> getAllCoreLicenses();

	public List<CoreLicense> getAllCoreLicenses(int page, int limit);

	public CoreLicense getCoreLicenseById(String id);

	public CoreLicense getCoreLicenseByLicenseNumber(String number);

	public void deleteCoreLicense(String id);

	public CoreLicense addCoreLicense(CoreLicense coreLicense);

	public CoreLicense editCoreLicense(CoreLicense coreLicense);
}
