package mw.nwra.ewaterpermit.service;

import java.util.Base64;
import java.util.Base64.Decoder;

import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;
import org.simplejavamail.config.ConfigLoader;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.SysConfig;
import mw.nwra.ewaterpermit.model.SysEmailTemplate;
import mw.nwra.ewaterpermit.model.SysUserAccount;

@Service(value = "mailingService")
public class MailingService {
	SysConfig config;
	SysEmailTemplate template;
	@Autowired
	SysConfigService configService;
	@Autowired
	SysEmailTemplateService templateService;

	private Mailer mailer;
	private Boolean messageSent = false;

	public void init(String templateName) {
		ConfigLoader.loadProperties("simplejavamail.properties", false); // optional default
//		ConfigLoader.loadProperties("overrides.properties"); // optional extra
		Decoder decoder = Base64.getDecoder();
		this.config = this.configService.getAllSysConfigurations().get(0);
		this.template = this.templateService.getSysEmailTemplatesByNameAndStatus(templateName, (short) 1).get(0);
		try {
			this.mailer = MailerBuilder
					.withSMTPServer(this.config.getSystemEmailSmtp(), this.config.getSystemEmailPort(),
							this.config.getSystemEmailAddress(),
							new String(decoder.decode(this.config.getSystemEmailAuth())))
					.withTransportStrategy(TransportStrategy.SMTPS).withSessionTimeout(10 * 1000)
//		          .clearEmailAddressCriteria() // turns off email validation
//		          cos we enabled smtps all properties have to be mail.smtps.*
					.withProperty("mail.smtps.sendpartial", true)
//		          .withDebugLogging(true)
					.async().buildMailer();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ForbiddenException("Failed to send email");
		}
	}

	public boolean send(String templateName, String token, SysUserAccount user) {
		this.init(templateName);
		String htmlTemplate = this.template.getValue();
		htmlTemplate = htmlTemplate.replaceAll("rbm_system_url_rbm", this.config.getSystemUrl());
		htmlTemplate = htmlTemplate.replaceAll("rbm_system_name_rbm", this.config.getSystemName());
		htmlTemplate = htmlTemplate.replaceAll("rbm_id_rbm", token);
		htmlTemplate = htmlTemplate.replaceAll("rbm_action_type_rbm", templateName.toLowerCase().replaceAll("_", " "));
		htmlTemplate = htmlTemplate.replaceAll("rbm_contact_postal_address_rbm", this.config.getContactPostalAddress());
//		System.out.println(htmlTemplate);
		Email email = EmailBuilder.startingBlank().from(this.config.getSystemEmailAddress())
				.to(user.getFirstName() + " " + user.getLastName(), user.getEmailAddress())
				.withSubject(this.config.getSystemName()).withHTMLText(htmlTemplate)
//		          .withPlainText("BlessK testing mail server from java")
				.buildEmail();
		try {
//			AsyncResponse asyncResponse = mailer.sendMail(email, true);
//			CompletableFuture<Void> asyncResponse = mailer.sendMail(email, true);
			mailer.sendMail(email, true);
			mailer.testConnection(true).whenComplete((result, ex) -> {
				if (ex != null) {
					System.err.printf("Execution failed %s", ex);
				} else {
					System.err.printf("Execution completed: %s", result);
					this.messageSent = true;
				}
			});

//			asyncResponse.onSuccess(() -> {
//				this.messageSent = true;
//			});
//			asyncResponse.onException((e) -> {
//				throw new ForbiddenException("Failed to send email");
//			});
		} catch (Exception e) {
			e.printStackTrace();
			throw new ForbiddenException("Failed to send email");
		} finally {
			this.mailer.shutdownConnectionPool();
		}
		return this.messageSent;
	}
}
