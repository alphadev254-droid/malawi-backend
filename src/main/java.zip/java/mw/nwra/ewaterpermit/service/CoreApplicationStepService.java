package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.CoreApplicationStep;
import mw.nwra.ewaterpermit.model.CoreLicenseType;

public interface CoreApplicationStepService {
	public List<CoreApplicationStep> getAllCoreApplicationSteps();

	public List<CoreApplicationStep> getAllCoreApplicationSteps(int page, int limit);

	public CoreApplicationStep getCoreApplicationStepById(String id);

	public CoreApplicationStep getCoreApplicationStepByName(String name);

	public void deleteCoreApplicationStep(String id);

	public CoreApplicationStep addCoreApplicationStep(CoreApplicationStep coreApplicationStep);

	public CoreApplicationStep editCoreApplicationStep(CoreApplicationStep coreApplicationStep);

	public List<CoreApplicationStep> getCoreApplicationStepByLicenseType(CoreLicenseType type);
}
