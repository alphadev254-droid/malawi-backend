package mw.nwra.ewaterpermit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mw.nwra.ewaterpermit.model.CoreLicense;
import mw.nwra.ewaterpermit.repository.CoreLicenseRepository;
import mw.nwra.ewaterpermit.util.AppUtil;

@Service(value = "coreLicenseService")
public class CoreLicenseServiceImpl implements CoreLicenseService {
	@Autowired
	CoreLicenseRepository repo;

	@Override
	public List<CoreLicense> getAllCoreLicenses() {
		return this.repo.findAll();
	}

	@Override
	public List<CoreLicense> getAllCoreLicenses(int page, int limit) {
		return this.repo.findAll(AppUtil.getPageRequest(page, limit, "dateCreated", "desc")).getContent();
	}

	@Override
	public CoreLicense getCoreLicenseById(String id) {
		return this.repo.findById(id).orElse(null);
	}

	@Override
	public CoreLicense getCoreLicenseByLicenseNumber(String number) {
		return this.repo.findByLicenseNumber(number);
	}

	@Override
	public void deleteCoreLicense(String id) {
		this.repo.deleteById(id);
	}

	@Override
	public CoreLicense addCoreLicense(CoreLicense coreLicense) {
		return this.repo.saveAndFlush(coreLicense);
	}

	@Override
	public CoreLicense editCoreLicense(CoreLicense coreLicense) {
		return this.repo.saveAndFlush(coreLicense);
	}
}
