package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.CoreApplicationPayment;

public interface CoreApplicationPaymentService {
	public List<CoreApplicationPayment> getAllCoreApplicationPayments();

	public List<CoreApplicationPayment> getAllCoreApplicationPayments(int page, int limit);

	public CoreApplicationPayment getCoreApplicationPaymentById(String id);

	public void deleteCoreApplicationPayment(String id);

	public CoreApplicationPayment addCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment);

	public CoreApplicationPayment editCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment);
}
