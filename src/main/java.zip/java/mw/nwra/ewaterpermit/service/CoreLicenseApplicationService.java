package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.CoreLicense;
import mw.nwra.ewaterpermit.model.CoreLicenseApplication;
import mw.nwra.ewaterpermit.model.SysUserAccount;

public interface CoreLicenseApplicationService {
	public List<CoreLicenseApplication> getAllCoreLicenseApplications();

	public List<CoreLicenseApplication> getAllCoreLicenseApplications(int page, int limit);

	public CoreLicenseApplication getCoreLicenseApplicationById(String id);

	public CoreLicenseApplication getCoreLicenseApplicationByOldLicense(CoreLicense licence);

	public void deleteCoreLicenseApplication(String id);

	public CoreLicenseApplication addCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication);

	public CoreLicenseApplication editCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication);

	public List<CoreLicenseApplication> getCoreLicenseApplicationByApplicant(SysUserAccount applicant);
}
