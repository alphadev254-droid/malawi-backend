package mw.nwra.ewaterpermit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mw.nwra.ewaterpermit.model.CoreLicense;
import mw.nwra.ewaterpermit.model.CoreLicenseApplication;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.repository.CoreLicenseApplicationRepository;
import mw.nwra.ewaterpermit.util.AppUtil;

@Service(value = "coreLicenseApplicationService")
public class CoreLicenseApplicationServiceImpl implements CoreLicenseApplicationService {
	@Autowired
	CoreLicenseApplicationRepository repo;

	@Override
	public List<CoreLicenseApplication> getAllCoreLicenseApplications() {
		return this.repo.findAll();
	}

	@Override
	public List<CoreLicenseApplication> getAllCoreLicenseApplications(int page, int limit) {
		return this.repo.findAll(AppUtil.getPageRequest(page, limit, "dateCreated", "desc")).getContent();
	}

	@Override
	public CoreLicenseApplication getCoreLicenseApplicationById(String id) {
		return this.repo.findById(id).orElse(null);
	}

	@Override
	public CoreLicenseApplication getCoreLicenseApplicationByOldLicense(CoreLicense licence) {
		return this.repo.findByCurrentLicense(licence);
	}

	@Override
	public void deleteCoreLicenseApplication(String id) {
		this.repo.deleteById(id);
	}

	@Override
	public CoreLicenseApplication addCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication) {
		return this.repo.saveAndFlush(coreLicenseApplication);
	}

	@Override
	public CoreLicenseApplication editCoreLicenseApplication(CoreLicenseApplication coreLicenseApplication) {
		return this.repo.saveAndFlush(coreLicenseApplication);
	}

	@Override
	public List<CoreLicenseApplication> getCoreLicenseApplicationByApplicant(SysUserAccount applicant) {
		return this.repo.findBySysUserAccount(applicant);
	}
}
