package mw.nwra.ewaterpermit.service;

import java.util.List;

import mw.nwra.ewaterpermit.model.SysUserAccount;

public interface SysUserAccountService {
	public List<SysUserAccount> getAllSysUserAccounts();

	public List<SysUserAccount> getAllSysUserAccounts(int page, int limit);

	public SysUserAccount getSysUserAccountById(String sysUserAccountId);

	public SysUserAccount getSysUserAccountByUsername(String username);

	public SysUserAccount getSysUserAccountByEmailAddress(String emailAddress);

	public SysUserAccount getSysUserAccountByPhoneNumber(String phoneNumber);

	public void deleteSysUserAccount(String sysUserAccountId);

	public SysUserAccount createSysUserAccount(SysUserAccount sysUserAccount);

	public SysUserAccount updateSysUserAccount(SysUserAccount sysUserAccount);
}
