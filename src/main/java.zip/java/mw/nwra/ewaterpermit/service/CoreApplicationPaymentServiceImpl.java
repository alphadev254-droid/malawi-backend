package mw.nwra.ewaterpermit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mw.nwra.ewaterpermit.model.CoreApplicationPayment;
import mw.nwra.ewaterpermit.repository.CoreApplicationPaymentRepository;
import mw.nwra.ewaterpermit.util.AppUtil;

@Service(value = "coreApplicationPaymentService")
public class CoreApplicationPaymentServiceImpl implements CoreApplicationPaymentService {
	@Autowired
	CoreApplicationPaymentRepository repo;

	@Override
	public List<CoreApplicationPayment> getAllCoreApplicationPayments() {
		return this.repo.findAll();
	}

	@Override
	public List<CoreApplicationPayment> getAllCoreApplicationPayments(int page, int limit) {
		return this.repo.findAll(AppUtil.getPageRequest(page, limit, "orderIndex", "asc")).getContent();
	}

	@Override
	public CoreApplicationPayment getCoreApplicationPaymentById(String id) {
		return this.repo.findById(id).orElse(null);
	}

	@Override
	public void deleteCoreApplicationPayment(String id) {
		this.repo.deleteById(id);
	}

	@Override
	public CoreApplicationPayment addCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment) {
		return this.repo.saveAndFlush(coreApplicationPayment);
	}

	@Override
	public CoreApplicationPayment editCoreApplicationPayment(CoreApplicationPayment coreApplicationPayment) {
		return this.repo.saveAndFlush(coreApplicationPayment);
	}
}
