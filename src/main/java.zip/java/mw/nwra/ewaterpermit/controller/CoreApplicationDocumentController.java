package mw.nwra.ewaterpermit.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.constant.Action;
import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreApplicationDocument;
import mw.nwra.ewaterpermit.model.CoreLicenseApplication;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.responseSchema.SearchResponse;
import mw.nwra.ewaterpermit.service.CoreApplicationDocumentService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/application-documents")
public class CoreApplicationDocumentController {
	private final String PREFIX = "doc_";
	private final String OBJ = "application-documents";
	@Autowired
	private CoreApplicationDocumentService documentService;

	@GetMapping(path = "")
	public SearchResponse getAllCoreApplicationDocuments(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit,
			@RequestParam(value = "query", defaultValue = "") String query) {
		SearchResponse res = this.documentService.getAllCoreApplicationDocuments(page, limit, query);
		if (res == null) {
			throw new EntityNotFoundException("Documents not found");
		}
		@SuppressWarnings("unchecked")
		List<CoreApplicationDocument> documents = (List<CoreApplicationDocument>) res.getData();
		res.setData(documents);
		return res;
	}

	@GetMapping(path = "/{id}")
	public CoreApplicationDocument getCoreApplicationDocumentById(@PathVariable(name = "id") String documentId) {
		CoreApplicationDocument document = this.documentService.getCoreApplicationDocumentById(documentId);
		if (document == null) {
			throw new EntityNotFoundException("Document not found");
		}
		return document;
	}

	@GetMapping(path = "/application/{id}")
	public List<CoreApplicationDocument> getCoreApplicationDocumentByApplication(
			@PathVariable(name = "id") String documentId) {
		CoreLicenseApplication appl = new CoreLicenseApplication();
		appl.setId(documentId);
		List<CoreApplicationDocument> documents = this.documentService.getCoreApplicationDocumentByApplication(appl);
		if (documents == null) {
			throw new EntityNotFoundException("Documents not found");
		}
		return documents;
	}

	@PostMapping(path = "")
	public CoreApplicationDocument createCoreApplicationDocument(@RequestBody Map<String, Object> documentRequest,
			@RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.CREATE.toString());

		CoreApplicationDocument document = (CoreApplicationDocument) AppUtil
				.objectToClass(CoreApplicationDocument.class, documentRequest);
		if (document == null) {
			throw new ForbiddenException("Could not create the document");
		}
//		if (document.getDocumentUrl() != null && AppUtil.isBase64File(document.getDocumentUrl())) {
//			String category = document.getCoreApplicationDocumentCategory().getName() + "_";
//			document.setDocumentUrl(AppUtil.uploadFile(this.PREFIX + category, document.getDocumentUrl()));
//		}
//		document.setSysUserAccount(ua);
		document.setDateCreated(new Timestamp(new Date().getTime()));
		return this.documentService.addCoreApplicationDocument(document);
	}

	@PutMapping(path = "/{id}")
	public CoreApplicationDocument updateCoreApplicationDocument(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> documentRequest, @RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.UPDATE.toString());

		CoreApplicationDocument document = this.documentService.getCoreApplicationDocumentById(id);
		if (document == null) {
			throw new EntityNotFoundException("Document not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(CoreApplicationDocument.class, documentRequest);
		CoreApplicationDocument documentFromObj = (CoreApplicationDocument) AppUtil
				.objectToClass(CoreApplicationDocument.class, documentRequest);
		if (documentFromObj == null) {
			throw new ForbiddenException("Could not update the document document");
		}
		if (documentFromObj.getDocumentUrl() != null && AppUtil.isBase64File(documentFromObj.getDocumentUrl())) {
			if (document.getDocumentUrl() != null) {
				AppUtil.deleteUploadedFile(document.getDocumentUrl());
			}
			String category = document.getCoreDocumentCategory().getName() + "_";
			documentFromObj
					.setDocumentUrl(AppUtil.uploadFile(this.PREFIX + category, documentFromObj.getDocumentUrl()));
		}
		if (documentFromObj.getDocumentUrl() == null && document.getDocumentUrl() != null) {
			AppUtil.deleteUploadedFile(document.getDocumentUrl());
		}
		BeanUtils.copyProperties(documentFromObj, document, propertiesToIgnore);
		document.setDateUpdated(new Timestamp(new Date().getTime()));
		this.documentService.editCoreApplicationDocument(document);
		return document;
	}

	@DeleteMapping(path = "/{id}")
	public CoreApplicationDocument deleteCoreApplicationDocument(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		AppUtil.can(AppUtil.getUserPermissions(ua), this.OBJ, Action.DELETE.toString());

		CoreApplicationDocument document = this.documentService.getCoreApplicationDocumentById(id);
		if (document == null) {
			throw new EntityNotFoundException("Document with id '" + id + "' not found");
		}
		this.documentService.deleteCoreApplicationDocument(document.getId());

		// delete from the file system
		AppUtil.deleteUploadedFile(document.getDocumentUrl());
		return document;
	}

	@PostMapping(path = "/upload")
	public ResponseEntity<?> uploadCoreApplicationDocument(@RequestBody Map<String, Object> data) {
		String url = null;
		if (AppUtil.isBase64File(data.get("data").toString())) {
			url = AppUtil.uploadFile("document_", data.get("data").toString());
		}
		return ResponseEntity.ok(url);
	}
}
