package mw.nwra.ewaterpermit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreFeesType;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.service.CoreFeesTypeService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/fees-types")
public class CoreFeesTypeController {

	@Autowired
	private CoreFeesTypeService coreFeesTypeService;

	@GetMapping(path = "")
	public List<CoreFeesType> getCoreFeesTypes(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<CoreFeesType> newsCategories = this.coreFeesTypeService.getAllCoreFeesTypes(page, limit);
		if (newsCategories.isEmpty()) {
			throw new EntityNotFoundException("Object not found");
		}
		return newsCategories;
	}

	@GetMapping(path = "/{id}")
	public CoreFeesType getCoreFeesTypeById(@PathVariable(name = "id") String id) {
		CoreFeesType coreFeesType = this.coreFeesTypeService.getCoreFeesTypeById(id);
		if (coreFeesType == null) {
			throw new EntityNotFoundException("Object not found");
		}
		return coreFeesType;
	}

	@PostMapping(path = "")
	public CoreFeesType createCoreFeesType(@RequestBody Map<String, Object> coreFeesTypeRequest) {
		CoreFeesType coreFeesType = (CoreFeesType) AppUtil.objectToClass(CoreFeesType.class, coreFeesTypeRequest);
		if (coreFeesType == null) {
			throw new ForbiddenException("Could not create the coreFeesType");
		}
		return this.coreFeesTypeService.addCoreFeesType(coreFeesType);
	}

	@PutMapping(path = "/{id}")
	public CoreFeesType updateCoreFeesType(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> coreFeesTypeRequest) {
		CoreFeesType coreFeesType = this.coreFeesTypeService.getCoreFeesTypeById(id);
		if (coreFeesType == null) {
			throw new EntityNotFoundException("Role not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(CoreFeesType.class, coreFeesTypeRequest);
		CoreFeesType coreFeesTypeFromObj = (CoreFeesType) AppUtil.objectToClass(CoreFeesType.class,
				coreFeesTypeRequest);
		if (coreFeesTypeFromObj == null) {
			throw new ForbiddenException("Could not update the Object");
		}
		BeanUtils.copyProperties(coreFeesTypeFromObj, coreFeesType, propertiesToIgnore);
		this.coreFeesTypeService.editCoreFeesType(coreFeesType);
		return coreFeesType;
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCoreFeesType(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		CoreFeesType categ = this.coreFeesTypeService.getCoreFeesTypeById(id);
		if (categ == null) {
			throw new EntityNotFoundException("User group not found");
		}
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		if (ua != null && ua.getSysUserGroup() != null && ua.getSysUserGroup().getName().equalsIgnoreCase("admin")) {
		} else {
			throw new EntityNotFoundException("Action denied");
		}
		this.coreFeesTypeService.deleteCoreFeesType(id);
	}
}
