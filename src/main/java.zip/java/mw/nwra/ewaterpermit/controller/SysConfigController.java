package mw.nwra.ewaterpermit.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.exception.UnauthorizedException;
import mw.nwra.ewaterpermit.model.SysConfig;
import mw.nwra.ewaterpermit.service.SysConfigService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/configs")
public class SysConfigController {
	@Autowired
	private SysConfigService configService;

	@GetMapping(path = "")
	public List<SysConfig> getAllConfigurations(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<SysConfig> configs = this.configService.getAllSysConfigurations(page, limit);
		if (configs.isEmpty()) {
			throw new EntityNotFoundException("Configurations not found");
		}
		return configs;
	}

	@GetMapping(path = "/{id}")
	public SysConfig getConfigById(@PathVariable(name = "id") String configId) {
		SysConfig config = this.configService.getSysConfigById(configId);
		if (config == null) {
			throw new EntityNotFoundException("Config not found");
		}
		return config;
	}

	@PostMapping
	public SysConfig createConfig(@RequestBody Map<String, Object> configRequest) {
		SysConfig config = (SysConfig) AppUtil.objectToClass(SysConfig.class, configRequest);
		if (config == null) {
			throw new ForbiddenException("Could not create the config");
		}
		config.setDateCreated(new Timestamp(new Date().getTime()));
		return this.configService.createSysConfig(config);
	}

	@PutMapping(path = "/{id}")
	public SysConfig updateConfig(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> configRequest) {
		SysConfig config = this.configService.getSysConfigById(id);
		if (config == null) {
			throw new EntityNotFoundException("System configuration not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(SysConfig.class, configRequest);
		SysConfig configFromObj = (SysConfig) AppUtil.objectToClass(SysConfig.class, configRequest);
		if (configFromObj == null) {
			throw new ForbiddenException("Could not update the config");
		}
		BeanUtils.copyProperties(configFromObj, config, propertiesToIgnore);
		config.setDateUpdated(new Timestamp(new Date().getTime()));
		return this.configService.updateSysConfig(config);
	}

	@GetMapping(path = "/accessdenied")
	public String accessDenied() {
		throw new UnauthorizedException("Operation denied");
	}
}
