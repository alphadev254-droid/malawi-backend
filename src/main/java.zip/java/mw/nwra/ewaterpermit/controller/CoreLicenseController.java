package mw.nwra.ewaterpermit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreLicense;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.service.CoreLicenseService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/licenses")
public class CoreLicenseController {

	@Autowired
	private CoreLicenseService coreLicenseService;

	@GetMapping(path = "")
	public List<CoreLicense> getCoreLicenses(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<CoreLicense> newsCategories = this.coreLicenseService.getAllCoreLicenses(page, limit);
		if (newsCategories.isEmpty()) {
			throw new EntityNotFoundException("Object not found");
		}
		return newsCategories;
	}

	@GetMapping(path = "/{id}")
	public CoreLicense getCoreLicenseById(@PathVariable(name = "id") String id) {
		CoreLicense coreLicense = this.coreLicenseService.getCoreLicenseById(id);
		if (coreLicense == null) {
			throw new EntityNotFoundException("Object not found");
		}
		return coreLicense;
	}

	@PostMapping(path = "")
	public CoreLicense createCoreLicense(@RequestBody Map<String, Object> coreLicenseRequest) {
		CoreLicense coreLicense = (CoreLicense) AppUtil.objectToClass(CoreLicense.class, coreLicenseRequest);
		if (coreLicense == null) {
			throw new ForbiddenException("Could not create the coreLicense");
		}
		return this.coreLicenseService.addCoreLicense(coreLicense);
	}

	@PutMapping(path = "/{id}")
	public CoreLicense updateCoreLicense(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> coreLicenseRequest) {
		CoreLicense coreLicense = this.coreLicenseService.getCoreLicenseById(id);
		if (coreLicense == null) {
			throw new EntityNotFoundException("Role not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(CoreLicense.class, coreLicenseRequest);
		CoreLicense coreLicenseFromObj = (CoreLicense) AppUtil.objectToClass(CoreLicense.class, coreLicenseRequest);
		if (coreLicenseFromObj == null) {
			throw new ForbiddenException("Could not update the Object");
		}
		BeanUtils.copyProperties(coreLicenseFromObj, coreLicense, propertiesToIgnore);
		this.coreLicenseService.editCoreLicense(coreLicense);
		return coreLicense;
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCoreLicense(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		CoreLicense categ = this.coreLicenseService.getCoreLicenseById(id);
		if (categ == null) {
			throw new EntityNotFoundException("User group not found");
		}
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		if (ua != null && ua.getSysUserGroup() != null && ua.getSysUserGroup().getName().equalsIgnoreCase("admin")) {
		} else {
			throw new EntityNotFoundException("Action denied");
		}
		this.coreLicenseService.deleteCoreLicense(id);
	}
}
