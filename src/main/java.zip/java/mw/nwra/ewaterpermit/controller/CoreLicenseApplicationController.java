package mw.nwra.ewaterpermit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreLicenseApplication;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.service.CoreLicenseApplicationService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/license-applications")
public class CoreLicenseApplicationController {

	@Autowired
	private CoreLicenseApplicationService coreLicenseApplicationService;

	@GetMapping(path = "")
	public List<CoreLicenseApplication> getCoreLicenseApplications(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<CoreLicenseApplication> newsCategories = this.coreLicenseApplicationService
				.getAllCoreLicenseApplications(page, limit);
		if (newsCategories.isEmpty()) {
			throw new EntityNotFoundException("Object not found");
		}
		return newsCategories;
	}

	@GetMapping(path = "/{id}")
	public CoreLicenseApplication getCoreLicenseApplicationById(@PathVariable(name = "id") String id) {
		CoreLicenseApplication coreLicenseApplication = this.coreLicenseApplicationService
				.getCoreLicenseApplicationById(id);
		if (coreLicenseApplication == null) {
			throw new EntityNotFoundException("Object not found");
		}
		return coreLicenseApplication;
	}

	@GetMapping(path = "/applicant/{id}")
	public List<CoreLicenseApplication> getCoreLicenseApplicationByApplicant(@PathVariable(name = "id") String id) {
		SysUserAccount applicant = new SysUserAccount();
		applicant.setId(id);
		List<CoreLicenseApplication> coreLicenseApplications = this.coreLicenseApplicationService
				.getCoreLicenseApplicationByApplicant(applicant);
		if (coreLicenseApplications.isEmpty()) {
			throw new EntityNotFoundException("LicenseApplication  not found");
		}
		return coreLicenseApplications;
	}

	@PostMapping(path = "")
	public CoreLicenseApplication createCoreLicenseApplication(
			@RequestBody Map<String, Object> coreLicenseApplicationRequest) {
		CoreLicenseApplication coreLicenseApplication = (CoreLicenseApplication) AppUtil
				.objectToClass(CoreLicenseApplication.class, coreLicenseApplicationRequest);
		if (coreLicenseApplication == null) {
			throw new ForbiddenException("Could not create the coreLicenseApplication");
		}
		return this.coreLicenseApplicationService.addCoreLicenseApplication(coreLicenseApplication);
	}

	@PutMapping(path = "/{id}")
	public CoreLicenseApplication updateCoreLicenseApplication(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> coreLicenseApplicationRequest) {
		CoreLicenseApplication coreLicenseApplication = this.coreLicenseApplicationService
				.getCoreLicenseApplicationById(id);
		if (coreLicenseApplication == null) {
			throw new EntityNotFoundException("Role not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(CoreLicenseApplication.class,
				coreLicenseApplicationRequest);
		CoreLicenseApplication coreLicenseApplicationFromObj = (CoreLicenseApplication) AppUtil
				.objectToClass(CoreLicenseApplication.class, coreLicenseApplicationRequest);
		if (coreLicenseApplicationFromObj == null) {
			throw new ForbiddenException("Could not update the Object");
		}
		BeanUtils.copyProperties(coreLicenseApplicationFromObj, coreLicenseApplication, propertiesToIgnore);
		this.coreLicenseApplicationService.editCoreLicenseApplication(coreLicenseApplication);
		return coreLicenseApplication;
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCoreLicenseApplication(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		CoreLicenseApplication categ = this.coreLicenseApplicationService.getCoreLicenseApplicationById(id);
		if (categ == null) {
			throw new EntityNotFoundException("User group not found");
		}
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		if (ua != null && ua.getSysUserGroup() != null && ua.getSysUserGroup().getName().equalsIgnoreCase("admin")) {
		} else {
			throw new EntityNotFoundException("Action denied");
		}
		this.coreLicenseApplicationService.deleteCoreLicenseApplication(id);
	}
}
