package mw.nwra.ewaterpermit.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.constant.SysAccountStatusValue;
import mw.nwra.ewaterpermit.constant.SysTemplateName;
import mw.nwra.ewaterpermit.constant.TemplateName;
import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.exception.UnauthorizedException;
import mw.nwra.ewaterpermit.model.SysAccountStatus;
import mw.nwra.ewaterpermit.model.SysDisposableDomain;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.model.SysUserAccountActivation;
import mw.nwra.ewaterpermit.model.SysUserGroup;
import mw.nwra.ewaterpermit.requestSchema.AuthenticationRequest;
import mw.nwra.ewaterpermit.requestSchema.OTPRequest;
import mw.nwra.ewaterpermit.requestSchema.OTPVerifyRequest;
import mw.nwra.ewaterpermit.requestSchema.ResetPasswordRequest;
import mw.nwra.ewaterpermit.requestSchema.SysUserAccountCreateRequest;
import mw.nwra.ewaterpermit.responseSchema.AuthenticationResponse;
import mw.nwra.ewaterpermit.service.CustomUserDetailsService;
import mw.nwra.ewaterpermit.service.MailingService;
import mw.nwra.ewaterpermit.service.SysAccountStatusService;
import mw.nwra.ewaterpermit.service.SysDisposableDomainService;
import mw.nwra.ewaterpermit.service.SysUserAccountActivationService;
import mw.nwra.ewaterpermit.service.SysUserAccountService;
import mw.nwra.ewaterpermit.util.AppUtil;
import mw.nwra.ewaterpermit.util.JwtUtil;
import mw.nwra.ewaterpermit.util.PasswordHash;

@RestController
@RequestMapping(value = "/v1/auth")
public class UserAuthController {

	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	CustomUserDetailsService userDetailsService;

	@Autowired
	private SysUserAccountService userAccountService;

	@Autowired
	private SysAccountStatusService accountStatusService;

	@Autowired
	private SysUserAccountActivationService userAccountActivationService;

	@Autowired
	private MailingService mailService;

	@Autowired
	JwtUtil jwtUtil;

//	@Autowired
//	MessagingService messagingService;

	@Autowired
	SysDisposableDomainService disposableDomainService;

	@PostMapping(path = "/sign-in")
	public ResponseEntity<?> authenticate(@RequestBody AuthenticationRequest request) throws Exception {
		String exceptionFound = null;

		SysUserAccount userAccount = this.userAccountService.getSysUserAccountByUsername(request.getUsername());
		if (userAccount != null && userAccount.getSysAccountStatus() != null) {
			if (userAccount.getSysAccountStatus().getName()
					.equalsIgnoreCase(SysAccountStatusValue.CONFIRM_ACCOUNT.toString())) {
				exceptionFound = "Unconfirmed account. Check your email for activation link.";
			} else if (userAccount.getSysAccountStatus().getName()
					.equalsIgnoreCase(SysAccountStatusValue.TEMPORARILY_DISABLED.toString())) {
				if (userAccount.getCanLoginAfter() != null
						&& new Timestamp(new Date().getTime()).before(userAccount.getCanLoginAfter())) {

					exceptionFound = "Your account has temporarily been disabled for security reasons. Try again later.";
				}
			} else if (userAccount.getSysAccountStatus().getName()
					.equalsIgnoreCase(SysAccountStatusValue.DEACTIVATED.toString())) {
				exceptionFound = "Your account has been suspended. Contact system administrator for help.";
			}
		}

		if (exceptionFound != null) {
			throw new UnauthorizedException(exceptionFound);
		}
		// authenticate
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
		} catch (Exception e) {
			throw new UnauthorizedException("Invalid credentials (Username or password incorrect)");
		}

		// copy old user details
//		SysUserAccount theUser = SerializationUtils.clone(userAccount);
//		userAccount.setLastLogin(new Timestamp(new Date().getTime()));
//		userAccount.setCanLoginAfter(null);
//		userAccount.setLastPasswordAttempt(new Timestamp(new Date().getTime()));
//		userAccount.setPasswordAttemptCount(0);
//		this.userAccountService.updateSysUserAccount(userAccount);

		final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
		final String token = jwtUtil.generateToken(userDetails, request.isRememberMe());
//		theUser = AppUtil.sanitizeSysUserAccount(theUser);

		return ResponseEntity.ok(new AuthenticationResponse(token, AppUtil.sanitizeSysUserAccount(userAccount),
				AppUtil.getUserPermissions(userAccount)));
	}

	@PostMapping(path = "/sign-up")
//	@Transactional
	public SysUserAccount createSysUserAccount(@RequestBody SysUserAccountCreateRequest userAccountCreateRequest) {
		SysUserAccount userAccount = new SysUserAccount();
		BeanUtils.copyProperties(userAccountCreateRequest, userAccount);
		userAccount.setDateCreated(new Timestamp(new Date().getTime()));
		if (userAccount.getPassword() != null && !userAccount.getPassword().trim().isEmpty()) {
			// hash password supplied
			userAccount.setPassword(PasswordHash.hashPassword(userAccount.getPassword()));
		} else {
			throw new ForbiddenException("Could not create the user account. Password unavailable.");
		}
		userAccount.setDateCreated(new Timestamp(new Date().getTime()));
		this.userAccountService.createSysUserAccount(userAccount);

		SysAccountStatus status = this.accountStatusService
				.getSysAccountStatusByName(SysAccountStatusValue.CONFIRM_ACCOUNT.toString());
		if (status == null) {
			throw new EntityNotFoundException("Could not find the proper account status");
		}
		userAccount.setSysAccountStatus(status);

		SysUserGroup grp = new SysUserGroup();
		grp.setId("308419ea-e8a5-11ef-b39b-c84bd6560e35"); // Applicant
		userAccount.setSysUserGroup(grp);

		SysUserAccount createdSysUserAccount = this.userAccountService.createSysUserAccount(userAccount);

		try {
			SysUserAccountActivation userActivation = AppUtil.createSysUserAccountActivation(createdSysUserAccount);

			userActivation = this.userAccountActivationService.addSysUserAccountActivation(userActivation);

			// lastly send the confirmation mail
			this.mailService.send(SysTemplateName.ACCOUNT_CONFIRMATION.toString(), userActivation.getToken(),
					userActivation.getSysUserAccount());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return AppUtil.sanitizeSysUserAccount(createdSysUserAccount);
	}

	@GetMapping(path = "/{token}/confirm-account")
	public SysUserAccount confirmAccount(@PathVariable(name = "token") String token) {
		SysUserAccountActivation userActivation = this.verifyToken(token);
		SysAccountStatus status = this.accountStatusService
				.getSysAccountStatusByName(SysAccountStatusValue.ACTIVE.toString());
		if (status == null) {
			throw new EntityNotFoundException("Could not find the proper account status");
		}
		// get the user again since the user from token verification is sanitized
		SysUserAccount userAccount = userActivation.getSysUserAccount();
		userAccount.setSysAccountStatus(status);
		userAccount.setDateUpdated(new Timestamp(new Date().getTime()));
		userAccount = this.userAccountService.updateSysUserAccount(userAccount);

		// update userAccount Activation
		userActivation.setSysUserAccount(userAccount);
		userActivation.setDateActivated(userAccount.getDateUpdated());

		this.userAccountActivationService.editSysUserAccountActivation(userActivation);
		return AppUtil.sanitizeSysUserAccount(userAccount);

	}

	@PostMapping(path = "/reset-password")
	public SysUserAccount resetPassword(@RequestBody ResetPasswordRequest resetPasswordRequest) {
		SysUserAccountActivation userActivation = this.verifyToken(resetPasswordRequest.getToken());

		// in case the user resort to reset password after forgetting credentials before
		// activating the account or after deactivating account, set active again
		SysAccountStatus status = this.accountStatusService
				.getSysAccountStatusByName(SysAccountStatusValue.ACTIVE.toString());
		if (status == null) {
			throw new EntityNotFoundException("Could not find the proper account status");
		}
		// get the user again since the user from token verification is sanitized
		SysUserAccount userAccount = userActivation.getSysUserAccount();
		userAccount.setSysAccountStatus(status);
		if (resetPasswordRequest.getPassword() != null) {
			// if new password supplied
			userAccount.setPassword(PasswordHash.hashPassword(resetPasswordRequest.getPassword()));
		}
		userAccount.setDateUpdated(new Timestamp(new Date().getTime()));
		userAccount = this.userAccountService.updateSysUserAccount(userAccount);

		// update userAccount Activation
		userActivation.setSysUserAccount(userAccount);
		userActivation.setDateActivated(userAccount.getDateUpdated());

		this.userAccountActivationService.editSysUserAccountActivation(userActivation);
		return AppUtil.sanitizeSysUserAccount(userAccount);
	}

	@GetMapping(path = "/{emailAddress}/reset-password")
	public SysUserAccount processPasswordResetRequest(@PathVariable(name = "emailAddress") String emailAddress) {
		SysUserAccount userAccount = this.userAccountService.getSysUserAccountByEmailAddress(emailAddress);
		if (userAccount == null) {
			throw new EntityNotFoundException("User account with email '" + emailAddress + "' does not exist");
		}
		SysUserAccountActivation userActivation = AppUtil.createSysUserAccountActivation(userAccount);
		userActivation = this.userAccountActivationService.addSysUserAccountActivation(userActivation);

		// lastly send the reset password mail
		this.mailService.send(SysTemplateName.PASSWORD_RESET.toString(), userActivation.getToken(),
				userActivation.getSysUserAccount());
		return AppUtil.sanitizeSysUserAccount(userAccount);
	}

	@GetMapping(path = "/{username}/username")
	public Map<String, Object> usernameExists(@PathVariable(name = "username") String username) {
		SysUserAccount userAccount = this.userAccountService.getSysUserAccountByUsername(username);
		if (userAccount != null) {
			throw new DataIntegrityViolationException("User account with username '" + username + "' already exists");
		}
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("username", username);
		results.put("exists", false);
		return results;
	}

	@GetMapping(path = "/{emailAddress}/email-address")
	public Map<String, Object> remailExists(@PathVariable(name = "emailAddress") String emailAddress) {
		// check temporary mail
		SysDisposableDomain disposableDomain = this.disposableDomainService
				.getSysDisposableDomainByName(emailAddress.split("@")[1]);
		if (disposableDomain != null) {
			throw new ForbiddenException("Disposable email address not allowed");
		}

		SysUserAccount userAccount = this.userAccountService.getSysUserAccountByEmailAddress(emailAddress);
		if (userAccount != null) {
			throw new ForbiddenException("User account with email '" + emailAddress + "' already exists");
		}
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("emailAddress", emailAddress);
		results.put("exists", false);
		return results;
	}

	@GetMapping(path = "/{emailAddress}/temp-mail")
	public Map<String, Object> isTempMail(@PathVariable(name = "emailAddress") String emailAddress) {
		// check temporary mail
		SysDisposableDomain disposableDomain = this.disposableDomainService
				.getSysDisposableDomainByName(emailAddress.split("@")[1]);
		if (disposableDomain != null) {
			throw new ForbiddenException("Disposable email address not allowed");
		}
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("emailAddress", emailAddress);
		results.put("exists", false);
		return results;
	}

	@GetMapping(path = "/{phoneNumber}/phone-number")
	public Map<String, Object> mobileNumberExists(@PathVariable(name = "phoneNumber") String phoneNumber) {
		SysUserAccount userAccount = this.userAccountService.getSysUserAccountByPhoneNumber(phoneNumber);
		if (userAccount != null) {
			throw new DataIntegrityViolationException(
					"User account with phone number '" + phoneNumber + "' already exists");
		}
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("phoneNumber", phoneNumber);
		results.put("exists", false);
		return results;
	}

	private SysUserAccountActivation verifyToken(String token) {
		SysUserAccountActivation userActivation = this.userAccountActivationService
				.getSysUserAccountActivationByTokenAndDate(token, new Timestamp(new Date().getTime()));
		if (userActivation == null) {
			throw new EntityNotFoundException("Invalid request or the verification period has expired.");
		}
		return userActivation;
	}

	@PostMapping(path = "/send-otp")
	public Map<String, Object> sendVerificationMessage(@RequestBody OTPRequest request) {
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("status", this.sendOTP(request, null));
		return results;
	}

	@PostMapping(path = "/verify-otp")
	public Map<String, Object> verifyUser(@RequestBody OTPVerifyRequest request) {
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("status", this.verifyOTP(request));
		return results;
	}

	public String sendOTP(OTPRequest request, SysUserAccount userAccount) {
		if (userAccount == null) {
			userAccount = new SysUserAccount();
			userAccount.setFirstName("Customer");
			userAccount.setLastName("");
			userAccount.setEmailAddress(request.getPayload());
		}

		SysUserAccountActivation userActivation = AppUtil.createSysUserAccountActivation(userAccount);
		SysUserAccountActivation tmpActivation = userActivation;
		tmpActivation.setSysUserAccount(null);
		tmpActivation.setEmailAddress(userAccount.getEmailAddress());
		tmpActivation = this.userAccountActivationService.addSysUserAccountActivation(tmpActivation);
		// lastly send the reset password mail
		boolean msgSent = this.mailService.send(TemplateName.TOKEN_VERIFICATION.toString(), userActivation.getToken(),
				userAccount);
		return msgSent ? "pending" : "failed"; // failed
	}

	public String verifyOTP(OTPVerifyRequest request) {
		SysUserAccountActivation userActivation = this.verifyToken(request.getOtp(), request.getPayload());
		if (userActivation != null) {
			userActivation.setDateActivated(new Timestamp(new Date().getTime()));
			this.userAccountActivationService.editSysUserAccountActivation(userActivation);
		}
		return userActivation != null ? "approved" : "failed";
	}

	public SysUserAccountActivation verifyToken(String token, String emailAddress) {
		SysUserAccountActivation userActivation = this.userAccountActivationService
				.getUserAccountActivationByTokenAndDateAndEmail(token, new Timestamp(new Date().getTime()),
						emailAddress);
		if (userActivation == null) {
			throw new EntityNotFoundException("Invalid request or the verification period has expired.");
		}
		if (userActivation.getSysUserAccount() != null)
			userActivation.setSysUserAccount(AppUtil.sanitizeSysUserAccount(userActivation.getSysUserAccount()));
		return userActivation;
	}
}
