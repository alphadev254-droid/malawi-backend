package mw.nwra.ewaterpermit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mw.nwra.ewaterpermit.exception.EntityNotFoundException;
import mw.nwra.ewaterpermit.exception.ForbiddenException;
import mw.nwra.ewaterpermit.model.CoreApplicationPayment;
import mw.nwra.ewaterpermit.model.SysUserAccount;
import mw.nwra.ewaterpermit.service.CoreApplicationPaymentService;
import mw.nwra.ewaterpermit.util.AppUtil;

@RestController
@RequestMapping(value = "/v1/application-payments")
public class CoreApplicationPaymentController {

	@Autowired
	private CoreApplicationPaymentService coreApplicationPaymentService;

	@GetMapping(path = "")
	public List<CoreApplicationPayment> getCoreApplicationPayments(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "50") int limit) {
		List<CoreApplicationPayment> newsCategories = this.coreApplicationPaymentService
				.getAllCoreApplicationPayments(page, limit);
		if (newsCategories.isEmpty()) {
			throw new EntityNotFoundException("Object not found");
		}
		return newsCategories;
	}

	@GetMapping(path = "/{id}")
	public CoreApplicationPayment getCoreApplicationPaymentById(@PathVariable(name = "id") String id) {
		CoreApplicationPayment coreApplicationPayment = this.coreApplicationPaymentService
				.getCoreApplicationPaymentById(id);
		if (coreApplicationPayment == null) {
			throw new EntityNotFoundException("Object not found");
		}
		return coreApplicationPayment;
	}

	@PostMapping(path = "")
	public CoreApplicationPayment createCoreApplicationPayment(
			@RequestBody Map<String, Object> coreApplicationPaymentRequest) {
		CoreApplicationPayment coreApplicationPayment = (CoreApplicationPayment) AppUtil
				.objectToClass(CoreApplicationPayment.class, coreApplicationPaymentRequest);
		if (coreApplicationPayment == null) {
			throw new ForbiddenException("Could not create the coreApplicationPayment");
		}
		return this.coreApplicationPaymentService.addCoreApplicationPayment(coreApplicationPayment);
	}

	@PutMapping(path = "/{id}")
	public CoreApplicationPayment updateCoreApplicationPayment(@PathVariable(name = "id") String id,
			@RequestBody Map<String, Object> coreApplicationPaymentRequest) {
		CoreApplicationPayment coreApplicationPayment = this.coreApplicationPaymentService
				.getCoreApplicationPaymentById(id);
		if (coreApplicationPayment == null) {
			throw new EntityNotFoundException("Role not found");
		}
		String[] propertiesToIgnore = AppUtil.getIgnoredProperties(CoreApplicationPayment.class,
				coreApplicationPaymentRequest);
		CoreApplicationPayment coreApplicationPaymentFromObj = (CoreApplicationPayment) AppUtil
				.objectToClass(CoreApplicationPayment.class, coreApplicationPaymentRequest);
		if (coreApplicationPaymentFromObj == null) {
			throw new ForbiddenException("Could not update the Object");
		}
		BeanUtils.copyProperties(coreApplicationPaymentFromObj, coreApplicationPayment, propertiesToIgnore);
		this.coreApplicationPaymentService.editCoreApplicationPayment(coreApplicationPayment);
		return coreApplicationPayment;
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCoreApplicationPayment(@PathVariable(name = "id") String id,
			@RequestHeader(name = "Authorization") String token) {
		CoreApplicationPayment categ = this.coreApplicationPaymentService.getCoreApplicationPaymentById(id);
		if (categ == null) {
			throw new EntityNotFoundException("Payment not found");
		}
		SysUserAccount ua = AppUtil.getLoggedInUser(token);
		if (ua != null && ua.getSysUserGroup() != null && ua.getSysUserGroup().getName().equalsIgnoreCase("admin")) {
		} else {
			throw new EntityNotFoundException("Action denied");
		}
		this.coreApplicationPaymentService.deleteCoreApplicationPayment(id);
	}
}
