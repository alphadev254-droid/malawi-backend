package mw.nwra.ewaterpermit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mw.nwra.ewaterpermit.model.SysUserAccount;

@Repository
public interface SysUserAccountRepository extends JpaRepository<SysUserAccount, String> {
	SysUserAccount findByUsername(String username);

	SysUserAccount findByEmailAddress(String emailAddress);

	SysUserAccount findByPhoneNumber(String phoneNumber);
}
